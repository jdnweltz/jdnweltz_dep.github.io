# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
import pickle
import sys
import os
import numpy as np
from numpy import random as rand
import time
import functools, multiprocessing
import pandas as pd
from BAISims import simulate

if __name__ == '__main__':
    print("hello world")
    taskID=int(os.environ['SLURM_ARRAY_TASK_ID'])
    sims = 1
    df = simulate(sims)
    df.to_pickle("./BAI_Simulation_Results" + str(taskID) +  ".pkl") 