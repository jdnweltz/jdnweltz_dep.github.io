#!/bin/bash
#SBATCH -e slurm_mod_%A_%a.err
#SBATCH -o slurm_mod_%A_%a.out
#SBATCH --array=201-400
#SBATCH --mem=5000
module load R/4.1.1-rhel8
Rscript --vanilla RDS_App_Sim_Aux.R
