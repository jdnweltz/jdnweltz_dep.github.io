#!/bin/bash
#SBATCH -e slurm_%A_%a.err
#SBATCH -o slurm_%A_%a.out
#SBATCH --array=1-899
#SBATCH --mem=1000
module load R
Rscript --vanilla RDS_Sim_Aux.R
