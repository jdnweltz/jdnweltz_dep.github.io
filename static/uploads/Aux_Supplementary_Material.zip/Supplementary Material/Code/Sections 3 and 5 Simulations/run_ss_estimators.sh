#!/bin/bash
#SBATCH -e slurm_%A_%a.err
#SBATCH -o slurm_%A_%a.out
#SBATCH --array=1-1899
#SBATCH --mem=1000
module load R/4.1.1-rhel8
Rscript --vanilla SS_Estimators.R
